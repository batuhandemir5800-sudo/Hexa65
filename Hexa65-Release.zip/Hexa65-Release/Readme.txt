İki Farklı Dünya: HEXA BASIC ve Donanım Kontrol Modu
Hexa-65, kullanıcılara iki farklı ve güçlü çalışma modu sunar. Bu modlar sayesinde hem BASIC gibi yüksek seviyeli bir dilde kolayca programlama yapabilir hem de emülatörün donanımına inerek düşük seviyede tam kontrol sağlayabilirsiniz.

1. HEXA BASIC Modu: Yüksek Seviyeli ve Yaratıcı Programlama
Bu mod, Hexa-65'i 1980'lerin ev bilgisayarları gibi kullanmanızı sağlar. Kendi oyunlarınızı, uygulamalarınızı ve demolarınızı yazmak için ideal, kullanıcı dostu bir ortamdır.

Nasıl Erişilir?
Ana Hexa:> komut satırındayken ROM yazıp Enter'a basarak HEXA BASIC yorumlayıcısını başlatabilirsiniz.

Öne Çıkan Özellikler:

Kolay Sözdizimi: PRINT, INPUT, LET gibi komutlarla programlamaya hızlı bir başlangıç yapın.

Tam Program Akış Kontrolü: IF...THEN, FOR...NEXT, GOTO, GOSUB...RETURN gibi yapılarla karmaşık algoritmalar ve programlar oluşturun.

Değişken Desteği: Sayısal (A, B), metinsel (A$, B$) ve hatta DIM komutu ile tek boyutlu diziler tanımlayabilirsiniz.

Zengin Fonksiyon Kütüphanesi: SQR (karekök), RND (rastgele sayı), LEN (uzunluk), LEFT$/RIGHT$/MID$ (metin işleme) gibi birçok dahili fonksiyona sahiptir.

Dosya Yönetimi: SAVE ve LOAD komutlarıyla yazdığınız BASIC programlarını kaydedebilir ve geri yükleyebilirsiniz. CATALOG ile mevcut .BAS dosyalarını listeleyebilirsiniz.

Donanıma Tam Erişim: POKE, PEEK ve SYS
HEXA BASIC, sizi sanal bir makineye hapsetmez. Aksine, emüle edilen donanımın kalbine inmenizi sağlayan güçlü komutlar sunar:

POKE adres, deger: Belleğin herhangi bir adresine (0 ile 65535 arası) doğrudan bir bayt (0-255) yazar. Bu, ekran belleğini manuel olarak değiştirmek, ses yongası kayıtçılarını ayarlamak veya makine kodu rutinlerine veri göndermek için kullanılabilir.

Örnek: POKE 512, 65 komutu, ekran belleğinin ilk karakterine 'A' harfini yazar (512 = $0200, 'A' = 65).

PEEK(adres): Herhangi bir bellek adresindeki baytı okur. Bu, klavye durumunu kontrol etmek, ekrandaki bir karakteri okumak veya donanım kayıtçılarının durumunu öğrenmek için idealdir.

PSET, SOUND, COLOR: POKE komutunun daha kullanıcı dostu versiyonlarıdır. Arka planda PPU ve APU'nun bellek adreslerine veri yazarak grafik ve ses kontrolü sağlarlar.

SYS adres: HEXA BASIC'in en güçlü komutlarından biridir. Emüle edilen 6502 CPU'sunun, belirtilen bellek adresinden itibaren makine kodu komutlarını çalıştırmasını tetikler. Bu sayede, BASIC'in yavaş kalacağı işleri (örneğin hızlı grafik çizimi) Assembly ile yazıp BASIC programınız içerisinden çağırabilirsiniz.

2. Donanım Kontrol Modu: Düşük Seviyeli Emülasyon ve Hata Ayıklama
Bu mod, Hexa-65'in varsayılan çalışma modudur ve size emülatörün çekirdeği üzerinde tam kontrol imkanı tanır. Assembly diliyle yazılmış programları çalıştırmak ve donanımın durumunu anlık olarak incelemek için tasarlanmıştır.

Nasıl Erişilir?
Hexa65.exe çalıştırıldığında sizi doğrudan Hexa:> komut istemiyle karşılar.

Öne Çıkan Özellikler:

Makine Kodu Yükleme (LOAD): LOAD "test.prg" gibi komutlarla, 6502 Assembly ile yazılıp derlenmiş programları (.prg dosyaları) doğrudan emülatörün belleğine yükleyebilirsiniz.

CPU'yu Çalıştırma (RUN): Belleğe yüklenmiş olan programı, belirlenen başlangıç adresinden (PC_Start) itibaren çalıştırmaya başlar. Bu komut, sanal CPU'yu hayata geçirir.

Doğrudan Bellek Erişimi (RAM): RAM komutu ile Ram:> adında özel bir moda geçersiniz. Bu modda wr adres veri (write) ve rd adres (read) komutlarıyla belleğin herhangi bir noktasını anlık olarak okuyabilir ve değiştirebilirsiniz. Bu, hata ayıklama için paha biçilmez bir araçtır.

Kayıtçıları ve Bayrakları Gözetleme (FROP): FROP (Flags-Registers-OP) komutu, o anki A, X, Y kayıtçılarının ve Zero, Negative, Carry gibi işlemci bayraklarının durumunu ekrana basar.

Program Sayacını Ayarlama (PC): RUN komutunun nereden başlayacağını belirleyen PC_Start adresini PC komutuyla değiştirebilirsiniz.

Bu iki modun bir arada bulunması, Hexa-65'i hem öğrenmesi kolay bir retro bilgisayar hem de donanım meraklıları için güçlü bir emülasyon platformu haline getirir.